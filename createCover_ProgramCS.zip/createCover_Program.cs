﻿using System;
using System.IO;
using PdfSharp.Pdf;
using PdfSharp.Pdf.IO;
using PdfSharp.Drawing;

class Program
{
    static void Main(string[] args)
    {
        // Create a single A4 PDF named page0cover.pdf containing centered name/surname and email in the following line
        string nameAndSurname = (args != null && args.Length > 0) ? args[0] : "Javier_Garcia";
        string emailAnd = (args != null && args.Length > 1) ? args[1] : "createCover.exe@ofimatica.website";
        string baseDir = AppContext.BaseDirectory;
        string outputPath = Path.Combine(baseDir, "page0cover_.pdf");

        try
        {
            using (PdfDocument doc = new PdfDocument())
            {
                PdfPage page = doc.AddPage();
                page.Size = PdfSharp.PageSize.A4;

                using (XGraphics gfx = XGraphics.FromPdfPage(page))
                {
                    XFont font = new XFont("Courier New", 16);

                    // Measure both lines and compute a vertically centered block
                    XSize nameSize = gfx.MeasureString(nameAndSurname, font);
                    XSize emailSize = string.IsNullOrEmpty(emailAnd) ? XSize.Empty : gfx.MeasureString(emailAnd, font);
                    // Insert a blank line between name and email: use name height + small gap
                    double spacing = string.IsNullOrEmpty(emailAnd) ? 0 : (nameSize.Height + 8);
                    double totalHeight = nameSize.Height + (string.IsNullOrEmpty(emailAnd) ? 0 : spacing + emailSize.Height);

                    double centerX = page.Width.Point / 2.0;
                    double centerY = page.Height.Point / 2.0;
                    double startY = centerY - (totalHeight / 2.0);

                    // Draw name centered
                    double nameCenterY = startY + (nameSize.Height / 2.0);
                    gfx.DrawString(nameAndSurname, font, XBrushes.Black, new XPoint(centerX, nameCenterY), XStringFormats.Center);

                    // Draw email below name if provided
                    if (!string.IsNullOrEmpty(emailAnd))
                    {
                        double emailCenterY = startY + nameSize.Height + spacing + (emailSize.Height / 2.0);
                        gfx.DrawString(emailAnd, font, XBrushes.Black, new XPoint(centerX, emailCenterY), XStringFormats.Center);
                    }
                }

                doc.Save(outputPath);
            }

            Console.WriteLine($" ");
            Console.WriteLine($"Creating a one-page-PDF-file with centered text:");
            Console.WriteLine($" ");
            Console.WriteLine($"Working folder: {baseDir}");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"\nSuccess! File created {outputPath}");
            Console.WriteLine($" ");
            Console.ResetColor();
        }
        catch (Exception ex)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"An error occurred: {ex.Message}");
            Console.ResetColor();
        }
    }
}